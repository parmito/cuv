/*
 * UartGsm.h
 *
 *  Created on: 24/09/2018
 *      Author: danilo
 */

#ifndef UARTGSM_H_
#define UARTGSM_H_

int UartGsmSendData(const char* logName, const char* data);
void UartGsminit(void);


#endif /* UARTGSM_H_ */
