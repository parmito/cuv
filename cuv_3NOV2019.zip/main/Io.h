/*
 * Io.h
 *
 *  Created on: 02/10/2018
 *      Author: danilo
 */

#ifndef IO_H_
#define IO_H_

xQueueHandle xQueueIo;
void Io_Init(void);


#endif /* IO_H_ */
