/*
 * RemoteReceiver.h
 *
 *  Created on: 30/10/2018
 *      Author: danilo
 */

#ifndef REMOTERECEIVER_H_
#define REMOTERECEIVER_H_

void RemoteReceiverInit(void);

#endif /* REMOTERECEIVER_H_ */
