/*
 * Debug.h
 *
 *  Created on: 20/09/2018
 *      Author: danilo
 */

#ifndef DEBUG_H_
#define DEBUG_H_

xQueueHandle xQueueDebug;
void DebugInit(void);

#endif /* DEBUG_H_ */
