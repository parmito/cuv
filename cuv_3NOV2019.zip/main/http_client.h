/*
 * http_client.h
 *
 *  Created on: 11 de fev de 2019
 *      Author: beelink
 */

#ifndef MAIN_HTTP_CLIENT_H_
#define MAIN_HTTP_CLIENT_H_

xQueueHandle xQueueHttpCli;
void Http_Init(void);


#endif /* MAIN_HTTP_CLIENT_H_ */
