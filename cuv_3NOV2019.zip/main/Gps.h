/*
 * gps.h
 *
 *  Created on: Oct 16, 2017
 *      Author: Danilo_2
 */

#ifndef GPS_H_
#define GPS_H_

void GpsInit(void);
void vTaskGps( void *pvParameters );

#endif /* GPS_H_ */
