/*
 * Gsm.h
 *
 *  Created on: 20/09/2018
 *      Author: danilo
 */

#ifndef GSM_H_
#define GSM_H_


xQueueHandle xQueueGsm;
void GsmInit(void);

#endif /* GSM_H_ */
