/*
 * gpsuart.h
 *
 *  Created on: 18/09/2018
 *      Author: danilo
 */

#ifndef GPSUART_H_
#define GPSUART_H_

void UartGpsinit(void);


#endif /* GPSUART_H_ */
